clear
clc

%matriz_VanDerMonde=dlmread('matriz_vander.txt');
res_VanDerMonde=dlmread('resultado.txt');
%res_VanDerMonde=dlmread('test 2/resultado_roundit_7.txt');


distacias=[-30 ,-20.71,-11.43,-2.14,7.14,16.43,25.71,35,44.29];
frecuencias=[0 ,1,2,5,23,13,5,2,0];

%genera la matriz de Van der Monde
matriz_VanDerMonde=ones(length(distacias),1);
for i=1:length(distacias)-1
    matriz_VanDerMonde=[matriz_VanDerMonde ((distacias.^i)')];
end

disp('matriz VanDerMonde')
disp(matriz_VanDerMonde)

disp('res VanDerMonde (codigo C)')
disp(res_VanDerMonde)

disp('Frecuencias (originales)')
disp(frecuencias')


disp('Coeficientes a_i')
% calcula los coeficientes despejando la ecuacion matricial
% matriz_VanDerMonde * matriz_coef = matriz_frecuencias
% matriz_coef = matriz_VanDerMonde_inversa * matriz_frecuencias

coef=inv(matriz_VanDerMonde)*frecuencias';
disp(coef)

disp('error entre codigo C y Matlab')
% el codigo en C devuelve los coeficientes
% error con los calculados de despejar la ecuacion matricial
for i=1:length(res_VanDerMonde)
    error(i)=res_VanDerMonde(i)-coef(i);
end
disp(error')

disp('frecuencias (Calculadas)')
% calcula las frecuencias multiplicando
% matriz_VanDerMonde * matriz_coeficientes 
frec_calculadas=round(matriz_VanDerMonde*coef);
disp(frec_calculadas)

